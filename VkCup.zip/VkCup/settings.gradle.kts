rootProject.name = "VkCup"
include(":app")
